package Client;

import java.io.FileNotFoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class UploadClient {

    public static void main(String[] args) throws RemoteException, NotBoundException, FileNotFoundException {

        while (1 == 1) {
            ClientFunction.UploadFile();
            ClientFunction.ManageFile();
        }

    }
}
