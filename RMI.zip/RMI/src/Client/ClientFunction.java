package Client;

import Server.IUpload;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Map;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

/**
 * @author Hà Viết Tráng - tuanPM
 * @date Mar 22, 2017 9:58:31 AM
 * @website haviettrang.blogspot.com
 * @Notes View my notes at haviettrang.postach.io
 */
public class ClientFunction {

    public static void UploadFile() throws RemoteException, FileNotFoundException, NotBoundException {

        Registry registry = LocateRegistry.getRegistry(9999);
        //    Trả về một tham khảo tới đội tượng từ xa với tên đưa ra
        //    tên này là do trên server quảng bá, nếu tên 
        IUpload manager = (IUpload) registry.lookup("phanleson");
        System.out.println("Đã tìm thấy đối tượng trên server...");

        //    Trả về một tham khảo tơi đối tượng Registry từ xa cho local host trên một port cụ thể
        //////////// để cho JFileChoose showup
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn File để up lên");

        JFrame jf = new JFrame("Dialog"); // added
        jf.setAlwaysOnTop(true); // added
        ////////////////

        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setVisible(true);
        int returnVal = fileChooser.showOpenDialog(jf);
        String path = fileChooser.getSelectedFile().getAbsolutePath();
        String fileName = fileChooser.getSelectedFile().getName();
        System.out.println("path: " + path + " filename: " + fileName);

        jf.dispose();//để cho JFilChooser show up

        manager.sendFileName(fileName);
        //
        FileInputStream fin = new FileInputStream(path);
        byte[] data = new byte[8192];
        int byteReads;
        try {
            byteReads = fin.read(data);
            while (byteReads != -1) {
                manager.sendData(data, 0, byteReads);
                byteReads = fin.read(data);
            }
            //    đóng file khi đã hoàn thành

            manager.closeUp();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Map<String, Long> ManageFile() throws RemoteException, NotBoundException {
        //    Trả về một tham khảo tơi đối tượng Registry từ xa cho local host trên một port cụ thể

        Registry registry = LocateRegistry.getRegistry(9999);
        //    Trả về một tham khảo tới đội tượng từ xa với tên đưa ra
        //    tên này là do trên server quảng bá, nếu tên 
        IUpload manager = (IUpload) registry.lookup("phanleson");

        Map<String, Long> namesMap = manager.showServerFile();
        for (String key : namesMap.keySet()) {
            System.out.println(key + " - " + namesMap.get(key));
            String name = key.toString() + " - " + namesMap.get(key).toString();
           
        }

        return namesMap;

    }

}
