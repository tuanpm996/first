package Server;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RunServer {
    
    public static void main(String[] args) throws RemoteException {

        //    tạo một thể hiên của Registry trên localhost mà lắng nghe trên port 9999
        //    đây có thể là bất cứ cổng nào bạn chọn
        Registry registry = LocateRegistry.createRegistry(9999);
        while (true) {            
            IUpload upload = new Server();
            //    Quảng bá đối tượng này trên server với tên "phanleson"
            // ở đây có thể là bất cứ tên nào bạn chọn, client sẽ tìm dựa vào số port
            //    và tên mà bạn quảng bá
            registry.rebind("phanleson", upload);
            //    nếu không xảy ra lỗi thì dòng này sẽ xuất hiện...
            System.out.println("Thành công quảng bá server...");
        }
        
    }
}
