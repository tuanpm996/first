package Server;

import java.rmi.RemoteException;

public interface IDownload {

    public void closeDown() throws RemoteException;

    public void receiveData(byte[] data, int offset, int length) throws RemoteException;

    public void getFileName(String fileName) throws RemoteException;

    
}
