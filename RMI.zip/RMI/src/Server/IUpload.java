package Server;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

public interface IUpload extends Remote {

    final public String ServerPath = "D:\\FileServer";

    public void closeUp() throws RemoteException;

    public void sendData(byte[] data, int offset, int length) throws RemoteException;

    public void sendFileName(String fileName) throws RemoteException;

    public Map<String, Long> showServerFile() throws RemoteException;
}
