package Server;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

/**
 * Server class Lớp này phải extends UnicastRemoteObject và implements một
 * interface mà định nghĩa các phương thức cho đối tượng từ xa viện gọi
 */
public class Server extends UnicastRemoteObject implements IUpload, IDownload {

    public Server() throws RemoteException {
        super();
    }

    FileOutputStream fout = null;

    @Override
    public void closeUp() throws RemoteException {
        if (fout != null) {
            try {
                fout.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void sendData(byte[] data, int offset, int length) throws RemoteException {
        if (fout != null) {
            try {
                fout.write(data, offset, length);
                fout.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void sendFileName(String fileName) throws RemoteException {
        if (fout == null) {
            try {
                File file = new File("D:\\FileServer\\" + fileName);
                if (file.exists()) {
                    System.out.println("File da ton tai");
                    fout = new FileOutputStream("D:\\FileServer\\" + fileName);
                } else {
                    fout = new FileOutputStream("D:\\FileServer\\" + fileName);
                }

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void receiveData(byte[] data, int offset, int length) throws RemoteException {

    }

    @Override
    public void getFileName(String fileName) throws RemoteException {

    }

    @Override
    public void closeDown() throws RemoteException {

    }

    @Override
    public Map<String, Long> showServerFile() throws RemoteException {
        File f = new File("D:\\FileServer");
        Map<String, Long> mapFile = new HashMap<String, Long>();
        for (File file : f.listFiles()) {
            mapFile.put(file.getName(), file.length());
        }
//        
        return mapFile;
    }

}
